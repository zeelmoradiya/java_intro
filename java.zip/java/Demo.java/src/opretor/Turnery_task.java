package opretor;

public class Turnery_task {
	public static void main(String[] args) {
		int a = 98;
		int b = 45;
		int c = 76;
		
		String r =  (a>b) ? (a>c ? "a is max" : "c is max"): (b>c ? "b is max" : "c is max");
		System.out.println(r);
	}

}
