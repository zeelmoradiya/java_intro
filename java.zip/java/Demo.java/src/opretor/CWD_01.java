package opretor;

public class CWD_01 {
	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a*b);
		System.out.println(a/b);
		System.out.println(a%b);
		
	}

}
